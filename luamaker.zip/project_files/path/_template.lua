return function() --points list
    local path = {
        {x=0, y=0, speed=0},
    }
    return path
end
