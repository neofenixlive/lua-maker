require("core")

function love.load()
    load_game()
end

function love.update(dt)
    update_game(dt)
end

function love.draw()
    draw_game()
end
