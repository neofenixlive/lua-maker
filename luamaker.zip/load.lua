local game = {
    window_title = "LuaMaker Example Project",
    window_version = "0.2",
    room_start = "example"
}
return game